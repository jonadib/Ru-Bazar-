# RU Market Design Guidelines

## Design Approach
**Reference-Based + System Approach**: Drawing inspiration from modern marketplace platforms like Facebook Marketplace, Carousell, and OLX, combined with university-friendly aesthetics. The design prioritizes ease of use for students while maintaining a professional, trustworthy appearance.

## Core Design Principles
1. **Student-Centric**: Approachable, familiar patterns that students can navigate effortlessly
2. **Trust & Safety**: Clear product information, seller profiles, and secure transaction pathways
3. **Visual Hierarchy**: Red and blue theme with strong contrast to guide attention
4. **Mobile-First**: Optimized for students browsing on phones between classes

## Color System
**Primary Colors**:
- Primary Blue: #1E40AF (Navigation, CTAs, links)
- Primary Red: #DC2626 (Accents, badges, sale indicators, important actions)
- Deep Navy: #1E293B (Text, headers)
- Light Blue: #DBEAFE (Backgrounds, cards)
- Light Red: #FEE2E2 (Alerts, highlights)

**Supporting Colors**:
- White: #FFFFFF (Backgrounds, cards)
- Gray 100: #F3F4F6 (Page backgrounds)
- Gray 600: #4B5563 (Secondary text)
- Gray 900: #111827 (Primary text)
- Success Green: #10B981 (Available status)
- Warning Orange: #F59E0B (Pending status)

## Typography
**Font Families** (via Google Fonts):
- Primary: Inter (body text, UI elements)
- Headers: Poppins (headings, logo text)

**Type Scale**:
- Hero Text: 3.5rem/4rem (Poppins Bold) - Landing page welcome
- H1: 2.5rem (Poppins SemiBold) - Page titles
- H2: 2rem (Poppins SemiBold) - Section headers
- H3: 1.5rem (Poppins Medium) - Card titles, product names
- Body Large: 1.125rem (Inter Regular) - Descriptions
- Body: 1rem (Inter Regular) - Default text
- Small: 0.875rem (Inter Regular) - Meta info, tags
- Caption: 0.75rem (Inter Medium) - Labels, badges

## Layout System
**Spacing Units**: Use Tailwind units of 2, 4, 6, 8, 12, 16, 20, 24
- Common spacing: p-4, m-6, gap-8
- Section padding: py-12 md:py-16 lg:py-20
- Card padding: p-6
- Form spacing: space-y-4

**Container Strategy**:
- Max width: max-w-7xl (1280px)
- Content sections: max-w-6xl
- Forms: max-w-md (centered)
- Product grids: Full container width

**Grid System**:
- Product Grid: grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4
- Category Grid: grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-3
- Dashboard: grid-cols-1 lg:grid-cols-3 (sidebar + main content)

## Component Library

### Navigation
**Header**: Sticky top navigation with white background, shadow on scroll
- Left: RU Market logo (provided image)
- Center: Search bar with category dropdown
- Right: Post Product (red button), User menu/Login
- Mobile: Hamburger menu, condensed search

**Category Navigation**: Horizontal scrollable pill buttons below header
- All categories listed with icons (Mobile, Laptop, etc.)
- Active state: Blue background, white text
- Inactive: White background, blue border

### Landing Page (Homepage)
**Hero Section**: Full-screen (100vh) background image (provided image)
- Dark overlay (40% opacity) for text readability
- Centered content:
  - "Welcome to RU Market" (Hero text, white, Poppins Bold)
  - Subtitle: "Buy and sell used products with fellow university students. Find great deals on phones, tablets, computers, bikes, and more!" (Body Large, white)
  - Search bar (white, large) with category dropdown
  - CTA button: "Start Selling" (Red, blurred background)
- Buttons with blur backdrop: backdrop-blur-md bg-white/20 (for transparency effect)

### Marketplace Section
**Horizontal Scrolling Carousel**: 
- Container: overflow-x-auto with smooth scrolling
- Product cards in a row with gap-4
- Auto-scroll animation (left to right, slow continuous loop)
- Navigation arrows on hover (large, semi-transparent circles)

**Product Card (Carousel)**:
- Image: aspect-ratio-square, object-cover, rounded-lg
- Overlay gradient at bottom for text
- Product name: Truncated to 2 lines, white text
- Price: Large, bold, red text
- Category badge: Small, blue pill, top-right corner

### Product Grid (Marketplace Area)
**Grid Layout**: Responsive grid with hover effects
- Card: White background, rounded-xl, shadow-sm, hover:shadow-lg transition
- Image: aspect-ratio-4/3, rounded-t-xl
- Content padding: p-4
- Product title: H3 size, truncate 2 lines
- Price: Large text, red color, font-bold
- Location & time: Small gray text, flex with icons
- Category badge: Blue pill badge
- Seller info: Small profile picture + name at bottom

### Product Upload Form
**Multi-step Form**:
- Step 1: Category selection (large icon cards)
- Step 2: Product details (title, description, price, condition)
- Step 3: Image upload (drag & drop zone, multi-image support)
- Step 4: Review & publish
- Progress indicator: Blue stepper at top
- Form fields: Large inputs, rounded-lg, border-2, focus:border-blue-500

### Product Detail Page
**Layout**: Two-column on desktop, stacked on mobile
- Left: Image gallery (main large image + thumbnail carousel below)
- Right: 
  - Product title (H1)
  - Price (large, red, bold)
  - Condition badge, Category badge
  - Description (full text)
  - Seller card (profile pic, name, join date, "Contact Seller" button)
  - Safety tips callout (blue background)

### User Dashboard
**Sidebar Navigation**:
- My Listings
- Favorites
- Messages (if implemented)
- Profile Settings
- Active tab: Blue background, rounded

**Listings Management**:
- Table/grid toggle view
- Each listing: Edit, Delete, Mark Sold actions
- Status indicators: Green (Active), Orange (Pending), Gray (Sold)

### Authentication Pages
**Login/Signup Forms**: Centered card on gradient background (blue to red diagonal)
- White card: rounded-2xl, shadow-2xl, p-8
- Logo at top
- Form fields: As described in upload form
- Primary CTA: Blue button, full width
- Social login options: Google, GitHub (via Replit Auth)
- Toggle between login/signup

## Icons
**Library**: Heroicons (via CDN)
- Use outline style for navigation, UI elements
- Use solid style for filled states, badges
- Size: w-5 h-5 for inline, w-6 h-6 for standalone, w-8 h-8 for feature icons

## Images
**Logo**: Use provided RU Market logo in header (height: 40px)
**Hero Background**: Full-screen provided image with overlay
**Product Images**: User-uploaded, enforce aspect ratios (square for cards, 4:3 for grids)
**Placeholder**: Use subtle gray pattern for missing images, not solid color

## Interactions & States
**Hover Effects**:
- Cards: Subtle lift (transform: translateY(-4px)), shadow increase
- Buttons: Slight darken, scale (0.98)
- Links: Underline, color shift to darker shade

**Active States**:
- Buttons: Pressed effect (transform: scale(0.95))
- Form inputs: Blue border, subtle shadow
- Navigation: Blue background for active page

**Loading States**:
- Skeleton loaders for product grids (pulsing gray rectangles)
- Spinner for form submissions (blue spinner)

## Accessibility
- All images have alt text
- Form labels explicitly associated with inputs
- Color contrast meets WCAG AA standards
- Keyboard navigation for all interactive elements
- Focus states visible with blue outline

## Responsive Breakpoints
- Mobile: < 768px (single column, stacked layouts)
- Tablet: 768px - 1024px (2-column grids)
- Desktop: > 1024px (3-4 column grids, full features)

## Key Page Structures
1. **Homepage**: Hero → Horizontal carousel → Category grid → Featured products grid
2. **Marketplace**: Category nav → Filters sidebar (desktop) → Product grid
3. **Product Detail**: Breadcrumb → Two-column layout → Related products
4. **Dashboard**: Sidebar → Main content area → Action modals

This design creates a vibrant, student-friendly marketplace that builds trust through clear information hierarchy and familiar e-commerce patterns, while the red-blue theme provides strong brand identity.