import ProductCard from "./ProductCard";

interface Product {
  id: string;
  title: string;
  price: number;
  category: string;
  condition: "New" | "Like New" | "Good" | "Fair";
  image: string;
  location: string;
  timeAgo: string;
  sellerName: string;
  sellerAvatar?: string;
}

interface ProductGridProps {
  products: Product[];
}

export default function ProductGrid({ products }: ProductGridProps) {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4" data-testid="grid-products">
      {products.map((product) => (
        <ProductCard key={product.id} {...product} />
      ))}
    </div>
  );
}
