import { Mail, MapPin, Phone } from "lucide-react";
import logoImage from "@assets/generated_images/RU_Market_logo_design_30644e64.png";

export default function Footer() {
  return (
    <footer className="bg-card border-t mt-12">
      <div className="mx-auto max-w-7xl px-4 py-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="space-y-3">
            <div className="flex items-center gap-2">
              <img src={logoImage} alt="RU Market" className="h-10 w-10" />
              <span className="text-xl font-bold text-primary" style={{ fontFamily: 'Poppins, sans-serif' }}>
                RU Market
              </span>
            </div>
            <p className="text-sm text-muted-foreground">
              Your trusted university marketplace for buying and selling used products.
            </p>
          </div>

          <div>
            <h3 className="font-semibold mb-3">Quick Links</h3>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li><a href="/" className="hover-elevate rounded px-1 cursor-pointer inline-block">Home</a></li>
              <li><a href="/marketplace" className="hover-elevate rounded px-1 cursor-pointer inline-block">Marketplace</a></li>
              <li><a href="/sell" className="hover-elevate rounded px-1 cursor-pointer inline-block">Sell Product</a></li>
              <li className="hover-elevate rounded px-1 cursor-pointer">My Listings</li>
            </ul>
          </div>

          <div>
            <h3 className="font-semibold mb-3">Categories</h3>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li className="hover-elevate rounded px-1 cursor-pointer">Electronics</li>
              <li className="hover-elevate rounded px-1 cursor-pointer">Books</li>
              <li className="hover-elevate rounded px-1 cursor-pointer">Furniture</li>
              <li className="hover-elevate rounded px-1 cursor-pointer">Sports</li>
            </ul>
          </div>

          <div>
            <h3 className="font-semibold mb-3">Contact</h3>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li className="flex items-center gap-2">
                <Mail className="h-4 w-4" />
                support@rumarket.edu
              </li>
              <li className="flex items-center gap-2">
                <Phone className="h-4 w-4" />
                (555) 123-4567
              </li>
              <li className="flex items-center gap-2">
                <MapPin className="h-4 w-4" />
                University Campus
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t mt-8 pt-6 text-center text-sm text-muted-foreground">
          <p>&copy; 2025 RU Market. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}
