import { MapPin, Clock, Heart } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { useState } from "react";
import { Button } from "@/components/ui/button";

interface ProductCardProps {
  id: string;
  title: string;
  price: number;
  category: string;
  condition: "New" | "Like New" | "Good" | "Fair";
  image: string;
  location: string;
  timeAgo: string;
  sellerName: string;
  sellerAvatar?: string;
}

export default function ProductCard({
  title,
  price,
  category,
  condition,
  image,
  location,
  timeAgo,
  sellerName,
  sellerAvatar,
}: ProductCardProps) {
  const [isFavorite, setIsFavorite] = useState(false);

  return (
    <Card className="overflow-hidden hover-elevate transition-all cursor-pointer group" data-testid="card-product">
      <div className="relative aspect-[4/3] overflow-hidden">
        <img
          src={image}
          alt={title}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
          data-testid="img-product"
        />
        <Badge className="absolute top-2 right-2 bg-primary text-primary-foreground" data-testid="badge-category">
          {category}
        </Badge>
        <Button
          variant="ghost"
          size="icon"
          className={`absolute top-2 left-2 h-8 w-8 rounded-full backdrop-blur-sm ${
            isFavorite ? "bg-accent text-accent-foreground" : "bg-white/80 text-foreground"
          }`}
          onClick={(e) => {
            e.stopPropagation();
            setIsFavorite(!isFavorite);
          }}
          data-testid="button-favorite"
        >
          <Heart className={`h-4 w-4 ${isFavorite ? "fill-current" : ""}`} />
        </Button>
      </div>
      
      <div className="p-4 space-y-3">
        <div>
          <h3 className="font-semibold text-base line-clamp-2 mb-1" data-testid="text-product-title">
            {title}
          </h3>
          <p className="text-xl font-bold text-accent" data-testid="text-product-price">
            ৳{price.toFixed(2)}
          </p>
        </div>

        <div className="flex items-center gap-2 text-xs text-muted-foreground">
          <Badge variant="outline" className="text-xs" data-testid="badge-condition">
            {condition}
          </Badge>
          <span className="flex items-center gap-1">
            <MapPin className="h-3 w-3" />
            {location}
          </span>
          <span className="flex items-center gap-1">
            <Clock className="h-3 w-3" />
            {timeAgo}
          </span>
        </div>

        <div className="flex items-center gap-2 pt-2 border-t">
          <Avatar className="h-6 w-6" data-testid="img-seller-avatar">
            <AvatarImage src={sellerAvatar} />
            <AvatarFallback className="text-xs">
              {sellerName.substring(0, 2).toUpperCase()}
            </AvatarFallback>
          </Avatar>
          <span className="text-sm text-muted-foreground" data-testid="text-seller-name">
            {sellerName}
          </span>
        </div>
      </div>
    </Card>
  );
}
