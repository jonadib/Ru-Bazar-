import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card } from "@/components/ui/card";
import { Upload, X } from "lucide-react";

const categories = [
  "Mobile", "Laptop", "Tablet", "Desktop", "Camera", "Headphone",
  "Smart Watch", "Refrigerator", "Furniture", "Cycle", "Book",
  "Stationery", "Sports Item", "Kitchen Item", "Beauty Product",
  "Home Decor", "Electronics"
];

const conditions = ["New", "Like New", "Good", "Fair"];

export default function ProductUploadForm() {
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [price, setPrice] = useState("");
  const [category, setCategory] = useState("");
  const [condition, setCondition] = useState("");
  const [location, setLocation] = useState("");
  const [imagePreview, setImagePreview] = useState<string | null>(null);

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setImagePreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = () => {
    console.log("Product submitted", {
      title,
      description,
      price,
      category,
      condition,
      location,
    });
  };

  return (
    <div className="max-w-2xl mx-auto p-6">
      <h2 className="text-2xl font-bold mb-6" style={{ fontFamily: 'Poppins, sans-serif' }} data-testid="text-form-title">
        List Your Product
      </h2>
      
      <div className="space-y-6">
        <Card className="p-6">
          <h3 className="font-semibold mb-4">Product Images</h3>
          <div className="space-y-4">
            {imagePreview ? (
              <div className="relative aspect-video rounded-lg overflow-hidden border">
                <img src={imagePreview} alt="Preview" className="w-full h-full object-cover" />
                <Button
                  variant="destructive"
                  size="icon"
                  className="absolute top-2 right-2"
                  onClick={() => setImagePreview(null)}
                  data-testid="button-remove-image"
                >
                  <X className="h-4 w-4" />
                </Button>
              </div>
            ) : (
              <label className="flex flex-col items-center justify-center w-full aspect-video border-2 border-dashed rounded-lg cursor-pointer hover-elevate transition-all">
                <Upload className="h-12 w-12 text-muted-foreground mb-2" />
                <span className="text-sm text-muted-foreground">Click to upload image</span>
                <input
                  type="file"
                  className="hidden"
                  accept="image/*"
                  onChange={handleImageUpload}
                  data-testid="input-image-upload"
                />
              </label>
            )}
          </div>
        </Card>

        <Card className="p-6 space-y-4">
          <h3 className="font-semibold mb-4">Product Details</h3>
          
          <div className="space-y-2">
            <Label htmlFor="title">Product Title *</Label>
            <Input
              id="title"
              placeholder="e.g., iPhone 13 Pro - 256GB"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              data-testid="input-product-title"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">Description *</Label>
            <Textarea
              id="description"
              placeholder="Describe your product, its condition, and any additional details..."
              rows={4}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              data-testid="input-product-description"
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="price">Price (৳) *</Label>
              <Input
                id="price"
                type="number"
                placeholder="0.00"
                value={price}
                onChange={(e) => setPrice(e.target.value)}
                data-testid="input-product-price"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="condition">Condition *</Label>
              <select
                id="condition"
                className="w-full px-3 py-2 border rounded-md bg-background"
                value={condition}
                onChange={(e) => setCondition(e.target.value)}
                data-testid="select-product-condition"
              >
                <option value="">Select condition</option>
                {conditions.map((c) => (
                  <option key={c} value={c}>{c}</option>
                ))}
              </select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="category">Category *</Label>
              <select
                id="category"
                className="w-full px-3 py-2 border rounded-md bg-background"
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                data-testid="select-product-category"
              >
                <option value="">Select category</option>
                {categories.map((cat) => (
                  <option key={cat} value={cat}>{cat}</option>
                ))}
              </select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="location">Location *</Label>
              <Input
                id="location"
                placeholder="e.g., Campus North"
                value={location}
                onChange={(e) => setLocation(e.target.value)}
                data-testid="input-product-location"
              />
            </div>
          </div>
        </Card>

        <div className="flex gap-3">
          <Button variant="outline" className="flex-1" data-testid="button-cancel">
            Cancel
          </Button>
          <Button className="flex-1 bg-accent hover:bg-accent text-accent-foreground" onClick={handleSubmit} data-testid="button-submit">
            Publish Listing
          </Button>
        </div>
      </div>
    </div>
  );
}
