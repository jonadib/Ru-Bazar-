import CategoryNav from '../CategoryNav';

export default function CategoryNavExample() {
  return <CategoryNav />;
}
