import ProductCard from '../ProductCard';

export default function ProductCardExample() {
  return (
    <div className="p-6 max-w-sm">
      <ProductCard
        id="1"
        title="iPhone 13 Pro Max - Excellent Condition"
        price={699.99}
        category="Mobile"
        condition="Like New"
        image="https://images.unsplash.com/photo-1632661674596-df8be070a5c5?w=400&h=300&fit=crop"
        location="Campus North"
        timeAgo="2h ago"
        sellerName="John Doe"
      />
    </div>
  );
}
