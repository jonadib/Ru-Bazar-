import ProductGrid from '../ProductGrid';

const mockProducts = [
  {
    id: "1",
    title: "iPhone 13 Pro Max - Excellent Condition",
    price: 699.99,
    category: "Mobile",
    condition: "Like New" as const,
    image: "https://images.unsplash.com/photo-1632661674596-df8be070a5c5?w=400&h=300&fit=crop",
    location: "Campus North",
    timeAgo: "2h ago",
    sellerName: "John Doe",
  },
  {
    id: "2",
    title: "Dell XPS 15 Laptop - 16GB RAM",
    price: 1299.99,
    category: "Laptop",
    condition: "Good" as const,
    image: "https://images.unsplash.com/photo-1593642632823-8f785ba67e45?w=400&h=300&fit=crop",
    location: "Main Library",
    timeAgo: "5h ago",
    sellerName: "Jane Smith",
  },
  {
    id: "3",
    title: "Samsung Galaxy Tab S8",
    price: 449.99,
    category: "Tablet",
    condition: "Like New" as const,
    image: "https://images.unsplash.com/photo-1544244015-0df4b3ffc6b0?w=400&h=300&fit=crop",
    location: "Student Center",
    timeAgo: "1d ago",
    sellerName: "Mike Johnson",
  },
  {
    id: "4",
    title: "Canon EOS R6 Camera",
    price: 1899.99,
    category: "Camera",
    condition: "Good" as const,
    image: "https://images.unsplash.com/photo-1516035069371-29a1b244cc32?w=400&h=300&fit=crop",
    location: "Arts Building",
    timeAgo: "3d ago",
    sellerName: "Sarah Lee",
  },
];

export default function ProductGridExample() {
  return (
    <div className="p-6">
      <ProductGrid products={mockProducts} />
    </div>
  );
}
