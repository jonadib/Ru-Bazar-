import ProductCarousel from '../ProductCarousel';

const mockProducts = [
  {
    id: "1",
    title: "MacBook Pro 16-inch 2021",
    price: 1899.99,
    category: "Laptop",
    image: "https://images.unsplash.com/photo-1517336714731-489689fd1ca8?w=400&h=400&fit=crop",
  },
  {
    id: "2",
    title: "iPhone 14 Pro - 256GB",
    price: 899.99,
    category: "Mobile",
    image: "https://images.unsplash.com/photo-1678652197831-2d180705cd2c?w=400&h=400&fit=crop",
  },
  {
    id: "3",
    title: "Sony WH-1000XM5 Headphones",
    price: 299.99,
    category: "Headphone",
    image: "https://images.unsplash.com/photo-1618366712010-f4ae9c647dcb?w=400&h=400&fit=crop",
  },
  {
    id: "4",
    title: "iPad Air 5th Gen",
    price: 499.99,
    category: "Tablet",
    image: "https://images.unsplash.com/photo-1544244015-0df4b3ffc6b0?w=400&h=400&fit=crop",
  },
  {
    id: "5",
    title: "Mountain Bike - Trek",
    price: 450.00,
    category: "Cycle",
    image: "https://images.unsplash.com/photo-1576435728678-68d0fbf94e91?w=400&h=400&fit=crop",
  },
];

export default function ProductCarouselExample() {
  return (
    <div className="py-6">
      <ProductCarousel products={mockProducts} />
    </div>
  );
}
