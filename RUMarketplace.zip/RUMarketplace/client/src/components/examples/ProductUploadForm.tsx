import ProductUploadForm from '../ProductUploadForm';

export default function ProductUploadFormExample() {
  return <ProductUploadForm />;
}
