import { Smartphone, Laptop, Tablet, Monitor, Camera, Headphones, Watch, Refrigerator, Armchair, Bike, BookOpen, Pencil, Trophy, Utensils, Sparkles, Home, Cpu } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { useState } from "react";

const categories = [
  { name: "All", icon: Home },
  { name: "Mobile", icon: Smartphone },
  { name: "Laptop", icon: Laptop },
  { name: "Tablet", icon: Tablet },
  { name: "Desktop", icon: Monitor },
  { name: "Camera", icon: Camera },
  { name: "Headphone", icon: Headphones },
  { name: "Smart Watch", icon: Watch },
  { name: "Refrigerator", icon: Refrigerator },
  { name: "Furniture", icon: Armchair },
  { name: "Cycle", icon: Bike },
  { name: "Book", icon: BookOpen },
  { name: "Stationery", icon: Pencil },
  { name: "Sports Item", icon: Trophy },
  { name: "Kitchen Item", icon: Utensils },
  { name: "Beauty Product", icon: Sparkles },
  { name: "Home Decor", icon: Home },
  { name: "Electronics", icon: Cpu },
];

export default function CategoryNav() {
  const [activeCategory, setActiveCategory] = useState("All");

  return (
    <div className="border-b bg-background">
      <div className="mx-auto max-w-7xl px-4 py-3">
        <div className="flex items-center gap-2 overflow-x-auto scrollbar-hide">
          {categories.map(({ name, icon: Icon }) => (
            <Badge
              key={name}
              variant={activeCategory === name ? "default" : "outline"}
              className={`cursor-pointer whitespace-nowrap ${
                activeCategory === name
                  ? "bg-primary text-primary-foreground"
                  : ""
              }`}
              onClick={() => setActiveCategory(name)}
              data-testid={`badge-category-${name.toLowerCase().replace(/\s+/g, '-')}`}
            >
              <Icon className="h-3 w-3 mr-1.5" />
              {name}
            </Badge>
          ))}
        </div>
      </div>
    </div>
  );
}
