import { Search, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useState } from "react";
import heroImage from "@assets/image_1761472392875.png";

export default function HeroSection() {
  const [searchQuery, setSearchQuery] = useState("");

  return (
    <div className="relative h-screen flex items-center justify-center overflow-hidden">
      <div
        className="absolute inset-0 bg-cover bg-center"
        style={{
          backgroundImage: `url(${heroImage})`,
        }}
      />
      <div className="absolute inset-0 bg-gradient-to-b from-black/60 via-black/50 to-black/60" />
      
      <div className="relative z-10 text-center px-4 max-w-4xl mx-auto">
        <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-white mb-4" style={{ fontFamily: 'Poppins, sans-serif' }} data-testid="text-hero-title">
          Welcome to RU Market
        </h1>
        <p className="text-lg md:text-xl text-white/90 mb-8 max-w-2xl mx-auto" data-testid="text-hero-subtitle">
          Buy and sell used products with fellow university students. Find great deals on phones, tablets, computers, bikes, and more!
        </p>
        
        <div className="flex flex-col sm:flex-row gap-3 max-w-2xl mx-auto mb-6">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
            <Input
              type="search"
              placeholder="What are you looking for?"
              className="pl-10 pr-4 h-12 text-base bg-white/95 backdrop-blur-sm"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              data-testid="input-hero-search"
            />
          </div>
          <Button className="h-12 px-6 bg-primary text-primary-foreground" data-testid="button-hero-search">
            Search
          </Button>
        </div>

        <a href="/sell">
          <Button
            variant="default"
            size="lg"
            className="bg-accent hover:bg-accent text-accent-foreground backdrop-blur-md"
            data-testid="button-start-selling"
          >
            Start Selling
            <ArrowRight className="ml-2 h-5 w-5" />
          </Button>
        </a>
      </div>
    </div>
  );
}
