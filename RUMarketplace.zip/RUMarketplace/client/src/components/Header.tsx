import { Search, Plus, User, Menu, X, LogOut, LayoutDashboard, UserCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useState } from "react";
import { Link } from "wouter";
import logoImage from "@assets/generated_images/RU_Market_logo_design_30644e64.png";
import { useAuth } from "@/hooks/useAuth";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

const categories = [
  "Mobile", "Laptop", "Tablet", "Desktop", "Camera", "Headphone",
  "Smart Watch", "Refrigerator", "Furniture", "Cycle", "Book",
  "Stationery", "Sports Item", "Kitchen Item", "Beauty Product",
  "Home Decor", "Electronics"
];

export default function Header() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("All");
  const { user, isAuthenticated } = useAuth();

  return (
    <header className="sticky top-0 z-50 bg-background border-b shadow-sm">
      <div className="mx-auto max-w-7xl px-4">
        <div className="flex items-center justify-between gap-4 py-3">
          <Link href="/" className="flex items-center gap-2 hover-elevate active-elevate-2 rounded-md px-2 py-1">
            <img src={logoImage} alt="RU Market" className="h-10 w-10" data-testid="img-logo" />
            <span className="text-xl font-bold text-primary" style={{ fontFamily: 'Poppins, sans-serif' }}>
              RU Market
            </span>
          </Link>

          <div className="hidden md:flex flex-1 max-w-2xl gap-2">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                type="search"
                placeholder="Search for products..."
                className="pl-10 pr-4"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                data-testid="input-search"
              />
            </div>
            <select
              className="px-3 py-2 border rounded-md bg-background text-sm"
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              data-testid="select-category"
            >
              <option value="All">All Categories</option>
              {categories.map((cat) => (
                <option key={cat} value={cat}>{cat}</option>
              ))}
            </select>
          </div>

          <div className="hidden md:flex items-center gap-2">
            <Link href="/sell">
              <Button variant="default" className="bg-accent hover:bg-accent text-accent-foreground" data-testid="button-post-product">
                <Plus className="h-4 w-4 mr-2" />
                Post Product
              </Button>
            </Link>
            {isAuthenticated ? (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="icon" className="rounded-full" data-testid="button-user-menu">
                    <Avatar className="h-8 w-8">
                      <AvatarImage src={user?.profileImageUrl || undefined} />
                      <AvatarFallback>
                        <User className="h-4 w-4" />
                      </AvatarFallback>
                    </Avatar>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <div className="px-2 py-1.5">
                    <p className="text-sm font-medium">{user?.firstName} {user?.lastName}</p>
                    <p className="text-xs text-muted-foreground">{user?.email}</p>
                  </div>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={() => window.location.href = "/profile"} data-testid="menu-item-profile">
                    <UserCircle className="mr-2 h-4 w-4" />
                    Profile
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => window.location.href = "/dashboard"} data-testid="menu-item-dashboard">
                    <LayoutDashboard className="mr-2 h-4 w-4" />
                    Dashboard
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={() => window.location.href = "/api/logout"} data-testid="menu-item-logout">
                    <LogOut className="mr-2 h-4 w-4" />
                    Logout
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            ) : (
              <Button variant="outline" onClick={() => window.location.href = "/api/login"} data-testid="button-login">
                Login
              </Button>
            )}
          </div>

          <Button
            variant="ghost"
            size="icon"
            className="md:hidden"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            data-testid="button-mobile-menu"
          >
            {mobileMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </Button>
        </div>

        {mobileMenuOpen && (
          <div className="md:hidden pb-4 space-y-3">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                type="search"
                placeholder="Search for products..."
                className="pl-10 pr-4"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                data-testid="input-search-mobile"
              />
            </div>
            <Link href="/sell" className="block">
              <Button variant="default" className="w-full bg-accent hover:bg-accent text-accent-foreground" data-testid="button-post-product-mobile">
                <Plus className="h-4 w-4 mr-2" />
                Post Product
              </Button>
            </Link>
            {isAuthenticated ? (
              <>
                <Button variant="outline" className="w-full" onClick={() => window.location.href = "/dashboard"} data-testid="button-dashboard-mobile">
                  <LayoutDashboard className="h-4 w-4 mr-2" />
                  Dashboard
                </Button>
                <Button variant="outline" className="w-full" onClick={() => window.location.href = "/profile"} data-testid="button-profile-mobile">
                  <UserCircle className="h-4 w-4 mr-2" />
                  Profile
                </Button>
                <Button variant="outline" className="w-full" onClick={() => window.location.href = "/api/logout"} data-testid="button-logout-mobile">
                  <LogOut className="h-4 w-4 mr-2" />
                  Logout
                </Button>
              </>
            ) : (
              <Button variant="outline" className="w-full" onClick={() => window.location.href = "/api/login"} data-testid="button-login-mobile">
                Login
              </Button>
            )}
          </div>
        )}
      </div>
    </header>
  );
}
