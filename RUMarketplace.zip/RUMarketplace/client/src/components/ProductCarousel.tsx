import { ChevronLeft, ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useRef } from "react";

interface Product {
  id: string;
  title: string;
  price: number;
  category: string;
  image: string;
}

interface ProductCarouselProps {
  products: Product[];
}

export default function ProductCarousel({ products }: ProductCarouselProps) {
  const scrollRef = useRef<HTMLDivElement>(null);

  const scroll = (direction: "left" | "right") => {
    if (scrollRef.current) {
      const scrollAmount = 300;
      scrollRef.current.scrollBy({
        left: direction === "left" ? -scrollAmount : scrollAmount,
        behavior: "smooth",
      });
    }
  };

  return (
    <div className="relative group">
      <Button
        variant="ghost"
        size="icon"
        className="absolute left-2 top-1/2 -translate-y-1/2 z-10 h-10 w-10 rounded-full bg-white/90 backdrop-blur-sm opacity-0 group-hover:opacity-100 transition-opacity shadow-lg hover-elevate"
        onClick={() => scroll("left")}
        data-testid="button-carousel-left"
      >
        <ChevronLeft className="h-5 w-5" />
      </Button>

      <div
        ref={scrollRef}
        className="flex gap-4 overflow-x-auto scrollbar-hide scroll-smooth px-4"
        style={{ scrollbarWidth: "none", msOverflowStyle: "none" }}
      >
        {products.map((product) => (
          <div
            key={product.id}
            className="flex-shrink-0 w-64 cursor-pointer hover-elevate rounded-lg overflow-hidden transition-all"
            data-testid={`card-carousel-product-${product.id}`}
          >
            <div className="relative aspect-square">
              <img
                src={product.image}
                alt={product.title}
                className="w-full h-full object-cover"
                data-testid={`img-carousel-product-${product.id}`}
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent" />
              <Badge className="absolute top-2 right-2 bg-primary text-primary-foreground" data-testid="badge-carousel-category">
                {product.category}
              </Badge>
              <div className="absolute bottom-0 left-0 right-0 p-4 text-white flex flex-col justify-end h-full">
                <h3 className="font-semibold line-clamp-2 mb-2 mt-auto" data-testid="text-carousel-title">
                  {product.title}
                </h3>
                <p className="text-xl font-bold text-accent" data-testid="text-carousel-price">
                  ৳{product.price.toFixed(2)}
                </p>
              </div>
            </div>
          </div>
        ))}
      </div>

      <Button
        variant="ghost"
        size="icon"
        className="absolute right-2 top-1/2 -translate-y-1/2 z-10 h-10 w-10 rounded-full bg-white/90 backdrop-blur-sm opacity-0 group-hover:opacity-100 transition-opacity shadow-lg hover-elevate"
        onClick={() => scroll("right")}
        data-testid="button-carousel-right"
      >
        <ChevronRight className="h-5 w-5" />
      </Button>
    </div>
  );
}
