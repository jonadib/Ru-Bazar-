import Header from "@/components/Header";
import CategoryNav from "@/components/CategoryNav";
import ProductGrid from "@/components/ProductGrid";
import Footer from "@/components/Footer";
import { SlidersHorizontal } from "lucide-react";
import { Button } from "@/components/ui/button";

const products = [
  {
    id: "1",
    title: "iPhone 13 Pro Max - Sierra Blue",
    price: 699.99,
    category: "Mobile",
    condition: "Like New" as const,
    image: "https://images.unsplash.com/photo-1632661674596-df8be070a5c5?w=400&h=300&fit=crop",
    location: "Campus North",
    timeAgo: "2h ago",
    sellerName: "John Doe",
  },
  {
    id: "2",
    title: "Dell XPS 15 - i7, 16GB RAM",
    price: 1299.99,
    category: "Laptop",
    condition: "Good" as const,
    image: "https://images.unsplash.com/photo-1593642632823-8f785ba67e45?w=400&h=300&fit=crop",
    location: "Main Library",
    timeAgo: "5h ago",
    sellerName: "Jane Smith",
  },
  {
    id: "3",
    title: "Samsung Galaxy Tab S8",
    price: 449.99,
    category: "Tablet",
    condition: "Like New" as const,
    image: "https://images.unsplash.com/photo-1544244015-0df4b3ffc6b0?w=400&h=300&fit=crop",
    location: "Student Center",
    timeAgo: "1d ago",
    sellerName: "Mike Johnson",
  },
  {
    id: "4",
    title: "Gaming PC - RTX 3070, 32GB RAM",
    price: 1599.99,
    category: "Desktop",
    condition: "Good" as const,
    image: "https://images.unsplash.com/photo-1587202372634-32705e3bf49c?w=400&h=300&fit=crop",
    location: "Tech Building",
    timeAgo: "12h ago",
    sellerName: "David Kim",
  },
  {
    id: "5",
    title: "Canon EOS R6 Camera",
    price: 1899.99,
    category: "Camera",
    condition: "Good" as const,
    image: "https://images.unsplash.com/photo-1516035069371-29a1b244cc32?w=400&h=300&fit=crop",
    location: "Arts Building",
    timeAgo: "3d ago",
    sellerName: "Sarah Lee",
  },
  {
    id: "6",
    title: "Sony WH-1000XM4 Headphones",
    price: 249.99,
    category: "Headphone",
    condition: "Good" as const,
    image: "https://images.unsplash.com/photo-1618366712010-f4ae9c647dcb?w=400&h=300&fit=crop",
    location: "Engineering",
    timeAgo: "1d ago",
    sellerName: "Alex Wong",
  },
  {
    id: "7",
    title: "Apple Watch Series 8 GPS",
    price: 349.99,
    category: "Smart Watch",
    condition: "Like New" as const,
    image: "https://images.unsplash.com/photo-1579586337278-3befd40fd17a?w=400&h=300&fit=crop",
    location: "Sports Complex",
    timeAgo: "6h ago",
    sellerName: "Emma Davis",
  },
  {
    id: "8",
    title: "Calculus Textbook 10th Edition",
    price: 45.00,
    category: "Book",
    condition: "Fair" as const,
    image: "https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?w=400&h=300&fit=crop",
    location: "Math Department",
    timeAgo: "2d ago",
    sellerName: "Tom Wilson",
  },
];

export default function MarketplacePage() {
  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <CategoryNav />
      
      <main className="flex-1 py-8">
        <div className="mx-auto max-w-7xl px-4">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h1 className="text-3xl font-bold" style={{ fontFamily: 'Poppins, sans-serif' }} data-testid="text-page-title">
                Marketplace
              </h1>
              <p className="text-muted-foreground mt-1">
                Browse {products.length} available products
              </p>
            </div>
            <Button variant="outline" data-testid="button-filters">
              <SlidersHorizontal className="h-4 w-4 mr-2" />
              Filters
            </Button>
          </div>

          <ProductGrid products={products} />
        </div>
      </main>

      <Footer />
    </div>
  );
}
