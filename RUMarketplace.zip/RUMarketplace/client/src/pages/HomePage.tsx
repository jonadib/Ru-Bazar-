import Header from "@/components/Header";
import CategoryNav from "@/components/CategoryNav";
import HeroSection from "@/components/HeroSection";
import ProductCarousel from "@/components/ProductCarousel";
import ProductGrid from "@/components/ProductGrid";
import Footer from "@/components/Footer";

const featuredProducts = [
  {
    id: "1",
    title: "MacBook Pro 16-inch M1 Pro",
    price: 1899.99,
    category: "Laptop",
    image: "https://images.unsplash.com/photo-1517336714731-489689fd1ca8?w=400&h=400&fit=crop",
  },
  {
    id: "2",
    title: "iPhone 14 Pro - 256GB Space Black",
    price: 899.99,
    category: "Mobile",
    image: "https://images.unsplash.com/photo-1678652197831-2d180705cd2c?w=400&h=400&fit=crop",
  },
  {
    id: "3",
    title: "Sony WH-1000XM5 Noise Cancelling",
    price: 299.99,
    category: "Headphone",
    image: "https://images.unsplash.com/photo-1618366712010-f4ae9c647dcb?w=400&h=400&fit=crop",
  },
  {
    id: "4",
    title: "iPad Air 5th Gen - WiFi 64GB",
    price: 499.99,
    category: "Tablet",
    image: "https://images.unsplash.com/photo-1544244015-0df4b3ffc6b0?w=400&h=400&fit=crop",
  },
  {
    id: "5",
    title: "Trek Mountain Bike - 21 Speed",
    price: 450.00,
    category: "Cycle",
    image: "https://images.unsplash.com/photo-1576435728678-68d0fbf94e91?w=400&h=400&fit=crop",
  },
  {
    id: "6",
    title: "Canon EOS R6 Mirrorless Camera",
    price: 1899.99,
    category: "Camera",
    image: "https://images.unsplash.com/photo-1516035069371-29a1b244cc32?w=400&h=400&fit=crop",
  },
];

const allProducts = [
  {
    id: "1",
    title: "iPhone 13 Pro Max - Excellent Condition",
    price: 699.99,
    category: "Mobile",
    condition: "Like New" as const,
    image: "https://images.unsplash.com/photo-1632661674596-df8be070a5c5?w=400&h=300&fit=crop",
    location: "Campus North",
    timeAgo: "2h ago",
    sellerName: "John Doe",
  },
  {
    id: "2",
    title: "Dell XPS 15 Laptop - 16GB RAM, 512GB SSD",
    price: 1299.99,
    category: "Laptop",
    condition: "Good" as const,
    image: "https://images.unsplash.com/photo-1593642632823-8f785ba67e45?w=400&h=300&fit=crop",
    location: "Main Library",
    timeAgo: "5h ago",
    sellerName: "Jane Smith",
  },
  {
    id: "3",
    title: "Samsung Galaxy Tab S8 - 128GB",
    price: 449.99,
    category: "Tablet",
    condition: "Like New" as const,
    image: "https://images.unsplash.com/photo-1544244015-0df4b3ffc6b0?w=400&h=300&fit=crop",
    location: "Student Center",
    timeAgo: "1d ago",
    sellerName: "Mike Johnson",
  },
  {
    id: "4",
    title: "Canon EOS R6 Camera Body",
    price: 1899.99,
    category: "Camera",
    condition: "Good" as const,
    image: "https://images.unsplash.com/photo-1516035069371-29a1b244cc32?w=400&h=300&fit=crop",
    location: "Arts Building",
    timeAgo: "3d ago",
    sellerName: "Sarah Lee",
  },
  {
    id: "5",
    title: "Sony WH-1000XM4 Headphones - Black",
    price: 249.99,
    category: "Headphone",
    condition: "Good" as const,
    image: "https://images.unsplash.com/photo-1618366712010-f4ae9c647dcb?w=400&h=300&fit=crop",
    location: "Engineering Wing",
    timeAgo: "1d ago",
    sellerName: "Alex Wong",
  },
  {
    id: "6",
    title: "Apple Watch Series 8 - 45mm GPS",
    price: 349.99,
    category: "Smart Watch",
    condition: "Like New" as const,
    image: "https://images.unsplash.com/photo-1579586337278-3befd40fd17a?w=400&h=300&fit=crop",
    location: "Sports Complex",
    timeAgo: "6h ago",
    sellerName: "Emma Davis",
  },
  {
    id: "7",
    title: "Mini Refrigerator - Perfect for Dorm",
    price: 89.99,
    category: "Refrigerator",
    condition: "Good" as const,
    image: "https://images.unsplash.com/photo-1571175443880-49e1d25b2bc5?w=400&h=300&fit=crop",
    location: "Residence Hall A",
    timeAgo: "2d ago",
    sellerName: "Chris Brown",
  },
  {
    id: "8",
    title: "Study Desk with Chair - Wooden",
    price: 120.00,
    category: "Furniture",
    condition: "Fair" as const,
    image: "https://images.unsplash.com/photo-1518455027359-f3f8164ba6bd?w=400&h=300&fit=crop",
    location: "West Campus",
    timeAgo: "4d ago",
    sellerName: "Lisa Chen",
  },
];

export default function HomePage() {
  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <CategoryNav />
      <HeroSection />
      
      <main className="flex-1">
        <section className="py-12 bg-muted/30">
          <div className="mx-auto max-w-7xl px-4">
            <h2 className="text-2xl font-bold mb-6" style={{ fontFamily: 'Poppins, sans-serif' }} data-testid="text-featured-title">
              Featured Products
            </h2>
            <ProductCarousel products={featuredProducts} />
          </div>
        </section>

        <section className="py-12">
          <div className="mx-auto max-w-7xl px-4">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-2xl font-bold" style={{ fontFamily: 'Poppins, sans-serif' }} data-testid="text-marketplace-title">
                Latest Listings
              </h2>
              <span className="text-sm text-muted-foreground">{allProducts.length} products</span>
            </div>
            <ProductGrid products={allProducts} />
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
}
