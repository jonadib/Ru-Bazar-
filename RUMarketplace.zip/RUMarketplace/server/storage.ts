import {
  users,
  products,
  type User,
  type UpsertUser,
  type UpdateUser,
  type Product,
  type InsertProduct,
  type UpdateProduct,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, and } from "drizzle-orm";

export interface IStorage {
  // User operations (required for Replit Auth)
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  updateUser(id: string, userData: UpdateUser): Promise<User>;

  // Product operations
  createProduct(userId: string, productData: InsertProduct): Promise<Product>;
  getProduct(id: string): Promise<Product | undefined>;
  getProducts(): Promise<Product[]>;
  getUserProducts(userId: string): Promise<Product[]>;
  updateProduct(id: string, userId: string, productData: UpdateProduct): Promise<Product>;
  deleteProduct(id: string, userId: string): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  async updateUser(id: string, userData: UpdateUser): Promise<User> {
    const [user] = await db
      .update(users)
      .set({
        ...userData,
        updatedAt: new Date(),
      })
      .where(eq(users.id, id))
      .returning();
    return user;
  }

  // Product operations
  async createProduct(userId: string, productData: InsertProduct): Promise<Product> {
    const [product] = await db
      .insert(products)
      .values({
        ...productData,
        userId,
      })
      .returning();
    return product;
  }

  async getProduct(id: string): Promise<Product | undefined> {
    const [product] = await db.select().from(products).where(eq(products.id, id));
    return product;
  }

  async getProducts(): Promise<Product[]> {
    return await db
      .select()
      .from(products)
      .where(eq(products.status, "active"))
      .orderBy(desc(products.createdAt));
  }

  async getUserProducts(userId: string): Promise<Product[]> {
    return await db
      .select()
      .from(products)
      .where(and(eq(products.userId, userId), eq(products.status, "active")))
      .orderBy(desc(products.createdAt));
  }

  async updateProduct(id: string, userId: string, productData: UpdateProduct): Promise<Product> {
    const [product] = await db
      .update(products)
      .set({
        ...productData,
        updatedAt: new Date(),
      })
      .where(and(eq(products.id, id), eq(products.userId, userId)))
      .returning();
    return product;
  }

  async deleteProduct(id: string, userId: string): Promise<void> {
    await db
      .update(products)
      .set({ status: "deleted", updatedAt: new Date() })
      .where(and(eq(products.id, id), eq(products.userId, userId)));
  }
}

export const storage = new DatabaseStorage();
